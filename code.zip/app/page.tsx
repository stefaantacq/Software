'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { FileUp, Zap, CheckCircle2, BookOpen, HistoryIcon } from 'lucide-react'
import Header from '@/components/header'
import WizardFlow from '@/components/wizard-flow'
import Dashboard from '@/components/dashboard'

export default function Home() {
  const [view, setView] = useState<'landing' | 'wizard' | 'dashboard'>('landing')

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      {view === 'landing' && (
        <div className="flex flex-col">
          {/* Hero Section */}
          <section className="px-4 py-20 md:py-32 border-b border-border">
            <div className="max-w-4xl mx-auto text-center space-y-8">
              <div className="space-y-4">
                <p className="text-sm font-medium text-muted-foreground">Powered by AI</p>
                <h1 className="text-4xl md:text-6xl font-bold leading-tight text-balance">
                  Verkoopscompromissen in minutenTijd
                </h1>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
                  Laat AI je helpen met het opstellen van professionele verkoopscompromissen. Upload je documenten, ontvang slimme suggesties per placeholder, en exporteer naar Word.
                </p>
              </div>

              <div className="flex gap-3 justify-center flex-wrap">
                <Button
                  onClick={() => setView('wizard')}
                  size="lg"
                  className="bg-primary text-primary-foreground hover:bg-primary/90"
                >
                  Nieuw Compromis
                </Button>
                <Button
                  onClick={() => setView('dashboard')}
                  size="lg"
                  variant="outline"
                  className="gap-2"
                >
                  <HistoryIcon className="w-4 h-4" />
                  Mijn Geschiedenis
                </Button>
              </div>
            </div>
          </section>

          {/* Features Section */}
          <section className="px-4 py-16 md:py-24">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-2xl md:text-3xl font-bold mb-12 text-center">
                Waarom Compromis AI?
              </h2>

              <div className="grid md:grid-cols-3 gap-6">
                {[
                  {
                    icon: FileUp,
                    title: 'Upload & Analyze',
                    description: 'Upload je verkoopsdocumenten en templates. AI scant automatisch de benodigde informatie.'
                  },
                  {
                    icon: Zap,
                    title: 'Slimme Suggesties',
                    description: 'Per placeholder krijg je contextuele informatie en AI-gegenereerde suggesties voor tekst.'
                  },
                  {
                    icon: CheckCircle2,
                    title: 'Kwaliteitscontrole',
                    description: 'Automatische checklists detecteren rode vlaggen en ontbrekende verplichte informatie.'
                  }
                ].map((feature, i) => (
                  <Card key={i} className="p-6 border border-border bg-card">
                    <feature.icon className="w-8 h-8 mb-4 text-primary" />
                    <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">{feature.description}</p>
                  </Card>
                ))}
              </div>
            </div>
          </section>

          {/* Requirements Section */}
          <section className="px-4 py-16 md:py-24 bg-muted/50 border-y border-border">
            <div className="max-w-4xl mx-auto">
              <div className="flex gap-4 mb-6">
                <BookOpen className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h2 className="text-2xl font-bold mb-4">Voorbeelden van benodigde informatie</h2>
                  <p className="text-muted-foreground mb-6">
                    Deze tool helpt je met de volgende onderdelen van het compromis:
                  </p>
                  
                  <ul className="space-y-2 text-sm">
                    {[
                      'Partijen (kopers & verkopers informatie)',
                      'Onroerend goed beschrijving (adres, type pand)',
                      'Koopprijs en betalingsvoorwaarden',
                      'Attesten & verplichte documenten checklist',
                      'Voorwaarden & bepalingen',
                      'Ondertekening & datums'
                    ].map((item, i) => (
                      <li key={i} className="flex gap-3">
                        <span className="text-primary font-bold">✓</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </section>
        </div>
      )}

      {view === 'wizard' && (
        <WizardFlow onBack={() => setView('landing')} />
      )}

      {view === 'dashboard' && (
        <Dashboard onBack={() => setView('landing')} />
      )}
    </div>
  )
}
