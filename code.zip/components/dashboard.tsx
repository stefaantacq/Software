'use client'

import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ArrowLeft, Plus, Trash2, Download, Clock } from 'lucide-react'

interface DashboardProps {
  onBack: () => void
}

export default function Dashboard({ onBack }: DashboardProps) {
  const recentContracts = [
    {
      id: 1,
      address: 'Singel 123, Amsterdam',
      price: '€ 425.000,-',
      date: '15 Nov 2025',
      status: 'draft',
      progress: 85
    },
    {
      id: 2,
      address: 'Keizersgracht 450, Amsterdam',
      price: '€ 595.000,-',
      date: '12 Nov 2025',
      status: 'completed',
      progress: 100
    },
    {
      id: 3,
      address: 'Prinsengracht 789, Amsterdam',
      price: '€ 350.000,-',
      date: '10 Nov 2025',
      status: 'completed',
      progress: 100
    }
  ]

  const statusLabel = {
    draft: 'Concept',
    completed: 'Voltooid'
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <Button
              variant="ghost"
              onClick={onBack}
              className="mb-4 gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Terug
            </Button>
            <h1 className="text-3xl font-bold">Mijn Compromissen</h1>
            <p className="text-muted-foreground mt-1">
              Bekijk en beheer je eerder gemaakte verkoopscompromissen
            </p>
          </div>
          <Button className="gap-2 bg-primary text-primary-foreground">
            <Plus className="w-4 h-4" />
            Nieuw
          </Button>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          {[
            { label: 'Totaal Compromissen', value: '23', icon: '📄' },
            { label: 'Deze Maand', value: '5', icon: '📅' },
            { label: 'Voltooid', value: '18', icon: '✓' }
          ].map((stat, i) => (
            <Card key={i} className="p-4 border border-border">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl font-bold mt-1">{stat.value}</p>
                </div>
                <span className="text-2xl">{stat.icon}</span>
              </div>
            </Card>
          ))}
        </div>

        {/* Contract List */}
        <Card className="border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50 border-b border-border">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Adres</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Prijs</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Datum</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Status</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Voortgang</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold">Acties</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {recentContracts.map((contract) => (
                  <tr key={contract.id} className="hover:bg-muted/50 transition-colors">
                    <td className="px-6 py-4">
                      <p className="font-medium text-sm">{contract.address}</p>
                    </td>
                    <td className="px-6 py-4 text-sm">{contract.price}</td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        {contract.date}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`text-xs px-2.5 py-1.5 rounded-full font-medium ${
                        contract.status === 'completed'
                          ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
                          : 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400'
                      }`}>
                        {statusLabel[contract.status as keyof typeof statusLabel]}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="w-20 bg-muted rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full transition-all"
                          style={{ width: `${contract.progress}%` }}
                        ></div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2 justify-end">
                        <button className="p-1.5 hover:bg-muted rounded transition-colors">
                          <Download className="w-4 h-4 text-primary" />
                        </button>
                        <button className="p-1.5 hover:bg-destructive/10 rounded transition-colors">
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  )
}
