'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ArrowLeft, Upload, Settings, Wand2, FileText } from 'lucide-react'
import DocumentUpload from '@/components/document-upload'
import TemplateConfig from '@/components/template-config'
import AnalysisPreview from '@/components/analysis-preview'
import ContractPreview from '@/components/contract-preview'

type WizardStep = 'upload' | 'template' | 'analysis' | 'preview'

interface WizardFlowProps {
  onBack: () => void
}

export default function WizardFlow({ onBack }: WizardFlowProps) {
  const [step, setStep] = useState<WizardStep>('upload')
  const [documents, setDocuments] = useState<File[]>([])
  const [templateData, setTemplateData] = useState<any>(null)

  const steps: { id: WizardStep; label: string; icon: any; description: string }[] = [
    { id: 'upload', label: 'Upload', icon: Upload, description: 'Voeg documenten toe' },
    { id: 'template', label: 'Template', icon: Settings, description: 'Configureer template' },
    { id: 'analysis', label: 'Analyse', icon: Wand2, description: 'AI Analyse' },
    { id: 'preview', label: 'Voorbeeld', icon: FileText, description: 'Controleer output' }
  ]

  const stepIndex = steps.findIndex(s => s.id === step)

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Progress Bar */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={onBack}
            className="mb-6 gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Terug
          </Button>

          <div className="space-y-4">
            <div className="flex justify-between gap-2">
              {steps.map((s, i) => {
                const isActive = s.id === step
                const isCompleted = i < stepIndex
                
                return (
                  <div key={s.id} className="flex-1">
                    <button
                      onClick={() => {
                        if (i <= stepIndex) setStep(s.id)
                      }}
                      className="w-full group"
                      disabled={i > stepIndex}
                    >
                      <div className={`
                        flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all
                        ${isActive ? 'bg-primary/10 border-primary' : isCompleted ? 'bg-primary/5 border-primary/50' : 'bg-muted border-border'}
                        ${i <= stepIndex ? 'cursor-pointer hover:border-primary' : 'opacity-50 cursor-not-allowed'}
                      `}>
                        <s.icon className={`w-5 h-5 ${isActive || isCompleted ? 'text-primary' : 'text-muted-foreground'}`} />
                        <span className={`text-xs font-medium text-center ${isActive ? 'text-primary' : 'text-muted-foreground'}`}>
                          {s.label}
                        </span>
                      </div>
                    </button>
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* Content */}
        <Card className="p-8 border border-border bg-card">
          {step === 'upload' && (
            <DocumentUpload
              onFilesSelected={(files) => {
                setDocuments(files)
                setStep('template')
              }}
            />
          )}

          {step === 'template' && (
            <TemplateConfig
              onConfigured={(config) => {
                setTemplateData(config)
                setStep('analysis')
              }}
            />
          )}

          {step === 'analysis' && (
            <AnalysisPreview
              documents={documents}
              templateData={templateData}
              onReady={() => setStep('preview')}
            />
          )}

          {step === 'preview' && (
            <ContractPreview onExport={() => {
              onBack()
            }} />
          )}
        </Card>
      </div>
    </div>
  )
}
