'use client'

import { useState } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Download, Printer, Copy, Check, AlertCircle } from 'lucide-react'

interface ContractPreviewProps {
  onExport: () => void
}

export default function ContractPreview({ onExport }: ContractPreviewProps) {
  const [copied, setCopied] = useState(false)
  const [exporting, setExporting] = useState(false)

  const handleCopy = () => {
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleExport = () => {
    setExporting(true)
    setTimeout(() => {
      // In a real app, this would generate and download a Word document
      const mockContent = `
VERKOOPSCOMPROMIS ONROEREND GOED

Datum: 15 november 2025

PARTIJEN:
Verkoper(s):
- Naam: Jan de Vries
- Adres: Singel 123, Amsterdam

Koper(s):
- Naam: [In te vullen]
- Adres: [In te vullen]

ONROEREND GOED:
Adres: Singel 123, 1012 AN Amsterdam
Type: Appartement
Oppervlakte: circa 65 m²
Bouwjaar: 1925 (Renovatie 2015)

KOOPPRIJS EN BETALINGSVOORWAARDEN:
Koopprijs: € 425.000,-
Betaald: Bij ondertekening notariële akte
Termijn: 8 weken na ondertekening van dit compromis

ATTESTEN EN DOCUMENTEN:
✓ Asbestverklaring: Aanwezig - Geen asbest
✓ Erfpachtcanon: N.v.t. (eigendomswoning)
⚠ Energielabel (EPC): Nog op te vragen
⚠ Bouwvergunningen: Verificatie nodig

BIJZONDERE BEPALINGEN:
- Dit compromis is onderworpen aan Nederlandse wetgeving
- Beide partijen verplichten zich tot notariele opmaking
- Eventuele erfdienstbaarheden: [Nader onderzoek]
      `

      // Create a blob and trigger download
      const blob = new Blob([mockContent], { type: 'text/plain' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'compromis_singel123.txt'
      a.click()
      URL.revokeObjectURL(url)

      setExporting(false)
      onExport()
    }, 1500)
  }

  const contractContent = `
VERKOOPSCOMPROMIS ONROEREND GOED

Datum: 15 november 2025

PARTIJEN:
Verkoper(s):
- Naam: Jan de Vries
- Adres: Singel 123, Amsterdam

Koper(s):
- Naam: [In te vullen]
- Adres: [In te vullen]

ONROEREND GOED:
Adres: Singel 123, 1012 AN Amsterdam
Type: Appartement
Oppervlakte: circa 65 m²
Bouwjaar: 1925 (Renovatie 2015)

KOOPPRIJS EN BETALINGSVOORWAARDEN:
Koopprijs: € 425.000,-
Betaald: Bij ondertekening notariële akte
Termijn: 8 weken na ondertekening van dit compromis

ATTESTEN EN DOCUMENTEN:
✓ Asbestverklaring: Aanwezig - Geen asbest
✓ Erfpachtcanon: N.v.t. (eigendomswoning)
⚠ Energielabel (EPC): Nog op te vragen
⚠ Bouwvergunningen: Verificatie nodig

BIJZONDERE BEPALINGEN:
- Dit compromis is onderworpen aan Nederlandse wetgeving
- Beide partijen verplichten zich tot notariele opmaking
- Eventuele erfdienstbaarheden: [Nader onderzoek]

Ondertekend te Amsterdam op [datum]:

Verkoper: ________________
Koper: ________________
Makelaar: ________________
  `

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Compromis Voorbeeld & Export</h2>
        <p className="text-muted-foreground">
          Controleer je gegenereerde compromis voordat je het exporteert
        </p>
      </div>

      {/* Warnings */}
      <Card className="p-4 border border-yellow-200 bg-yellow-50 dark:bg-yellow-950/20">
        <div className="flex gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 dark:text-yellow-400 flex-shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="font-semibold text-yellow-900 dark:text-yellow-100 mb-1">
              Controleren voordat je ondertekent
            </p>
            <p className="text-yellow-800 dark:text-yellow-200">
              Zorg ervoor dat alle kopergegevens ingevuld zijn en rode vlaggen opgelost zijn.
            </p>
          </div>
        </div>
      </Card>

      {/* Editor */}
      <Card className="p-6 border border-border bg-card">
        <div className="flex gap-3 mb-6 pb-4 border-b border-border flex-wrap">
          <Button
            size="sm"
            variant="outline"
            className="gap-2"
            onClick={handleCopy}
          >
            {copied ? (
              <>
                <Check className="w-4 h-4" />
                Gekopieerd
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                Kopiëren
              </>
            )}
          </Button>
          <Button size="sm" variant="outline" className="gap-2">
            <Printer className="w-4 h-4" />
            Afdrukken
          </Button>
          <Button
            size="sm"
            className="gap-2 bg-primary text-primary-foreground ml-auto"
            onClick={handleExport}
            disabled={exporting}
          >
            <Download className="w-4 h-4" />
            {exporting ? 'Exporteren...' : 'Naar Word'}
          </Button>
        </div>

        <pre className="bg-muted p-6 rounded-lg text-sm font-mono text-foreground overflow-auto max-h-96 leading-relaxed">
          {contractContent}
        </pre>
      </Card>

      {/* Checklist */}
      <Card className="p-4 border border-border bg-muted/50">
        <h3 className="font-semibold mb-3">Controleerlijst voor export:</h3>
        <ul className="space-y-2 text-sm">
          {[
            { label: 'Alle partijgegevens ingevuld', done: false },
            { label: 'Adres en eigenschappen accuraat', done: true },
            { label: 'Rode vlaggen opgelost (EPC, bouwvergunning)', done: false },
            { label: 'Ondertekeningsdatums ingevuld', done: false }
          ].map((item, i) => (
            <label key={i} className="flex items-center gap-3 cursor-pointer hover:bg-background/50 p-2 rounded transition-colors">
              <input
                type="checkbox"
                defaultChecked={item.done}
                className="w-4 h-4 rounded border-border cursor-pointer"
              />
              <span className={item.done ? 'text-muted-foreground line-through' : ''}>
                {item.label}
              </span>
            </label>
          ))}
        </ul>
      </Card>

      {/* Footer Actions */}
      <div className="flex gap-3 justify-end pt-4 border-t border-border">
        <Button variant="outline">
          Terug Bewerken
        </Button>
        <Button
          onClick={handleExport}
          disabled={exporting}
          className="gap-2 bg-primary text-primary-foreground"
        >
          <Download className="w-4 h-4" />
          {exporting ? 'Bezig...' : 'Exporteren'}
        </Button>
      </div>
    </div>
  )
}
