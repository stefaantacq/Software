'use client'

import { Building2 } from 'lucide-react'

export default function Header() {
  return (
    <header className="border-b border-border bg-background">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-primary text-primary-foreground p-2 rounded-lg">
            <Building2 className="w-5 h-5" />
          </div>
          <h1 className="text-xl font-bold">Compromis AI</h1>
        </div>
        <p className="text-sm text-muted-foreground hidden md:block">
          Vastgoedmakelaars tool
        </p>
      </div>
    </header>
  )
}
