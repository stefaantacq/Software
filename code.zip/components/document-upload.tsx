'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Upload, File, X } from 'lucide-react'

interface DocumentUploadProps {
  onFilesSelected: (files: File[]) => void
}

export default function DocumentUpload({ onFilesSelected }: DocumentUploadProps) {
  const [files, setFiles] = useState<File[]>([])
  const [dragActive, setDragActive] = useState(false)

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true)
    } else if (e.type === 'dragleave') {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    const newFiles = Array.from(e.dataTransfer.files).filter(
      file => file.type.includes('pdf') || file.type.includes('word') || file.type.includes('text')
    )
    setFiles(prev => [...prev, ...newFiles])
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files)
      setFiles(prev => [...prev, ...newFiles])
    }
  }

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index))
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Upload Documenten</h2>
        <p className="text-muted-foreground">
          Upload je verkoopsdocumenten en templates (PDF, Word, of tekst)
        </p>
      </div>

      {/* Upload Area */}
      <div
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        className={`
          border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer
          ${dragActive ? 'bg-primary/10 border-primary' : 'bg-muted/50 border-border hover:border-primary/50'}
        `}
      >
        <Upload className="w-10 h-10 mx-auto mb-3 text-primary opacity-60" />
        <h3 className="font-semibold mb-1">Sleep bestanden hier of klik</h3>
        <p className="text-sm text-muted-foreground mb-4">Ondersteund: PDF, Word, TXT</p>
        
        <input
          type="file"
          multiple
          onChange={handleFileInput}
          accept=".pdf,.doc,.docx,.txt"
          className="hidden"
          id="file-input"
        />
        <label htmlFor="file-input">
          <Button asChild variant="outline">
            <span>Bestand selecteren</span>
          </Button>
        </label>
      </div>

      {/* File List */}
      {files.length > 0 && (
        <div className="space-y-2">
          <h3 className="font-semibold">Geüploade bestanden ({files.length})</h3>
          <div className="space-y-2">
            {files.map((file, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <File className="w-5 h-5 text-primary opacity-60" />
                  <div className="text-sm">
                    <p className="font-medium">{file.name}</p>
                    <p className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(1)} KB</p>
                  </div>
                </div>
                <button
                  onClick={() => removeFile(i)}
                  className="p-1 hover:bg-destructive/10 rounded transition-colors"
                >
                  <X className="w-4 h-4 text-destructive" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-3 justify-end pt-4">
        <Button
          onClick={() => onFilesSelected(files)}
          disabled={files.length === 0}
          className="bg-primary text-primary-foreground"
        >
          Doorgaan ({files.length})
        </Button>
      </div>
    </div>
  )
}
