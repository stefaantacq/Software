'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Plus, Trash2 } from 'lucide-react'

interface TemplateConfigProps {
  onConfigured: (config: any) => void
}

export default function TemplateConfig({ onConfigured }: TemplateConfigProps) {
  const [templateSections, setTemplateSections] = useState([
    { id: 1, name: 'Partijen', required: true },
    { id: 2, name: 'Onroerend Goed', required: true },
    { id: 3, name: 'Koopprijs', required: true }
  ])
  const [newSection, setNewSection] = useState('')

  const addSection = () => {
    if (newSection.trim()) {
      setTemplateSections([
        ...templateSections,
        {
          id: Math.max(...templateSections.map(s => s.id), 0) + 1,
          name: newSection,
          required: false
        }
      ])
      setNewSection('')
    }
  }

  const removeSection = (id: number) => {
    setTemplateSections(templateSections.filter(s => s.id !== id))
  }

  const toggleRequired = (id: number) => {
    setTemplateSections(
      templateSections.map(s =>
        s.id === id ? { ...s, required: !s.required } : s
      )
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Template Configuratie</h2>
        <p className="text-muted-foreground">
          Definieer de onderdelen van je compromis template
        </p>
      </div>

      {/* Sections List */}
      <div className="space-y-3">
        {templateSections.map(section => (
          <Card key={section.id} className="p-4 border border-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 flex-1">
                <input
                  type="checkbox"
                  checked={section.required}
                  onChange={() => toggleRequired(section.id)}
                  className="w-4 h-4 rounded border-border cursor-pointer"
                />
                <div>
                  <p className="font-medium">{section.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {section.required ? 'Verplicht' : 'Optioneel'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => removeSection(section.id)}
                className="p-2 hover:bg-destructive/10 rounded transition-colors"
              >
                <Trash2 className="w-4 h-4 text-destructive" />
              </button>
            </div>
          </Card>
        ))}
      </div>

      {/* Add New Section */}
      <div className="flex gap-2">
        <input
          type="text"
          value={newSection}
          onChange={(e) => setNewSection(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && addSection()}
          placeholder="Nieuwe sectie toevoegen..."
          className="flex-1 px-3 py-2 rounded border border-input bg-background text-foreground placeholder-muted-foreground"
        />
        <Button
          onClick={addSection}
          variant="outline"
          size="icon"
        >
          <Plus className="w-4 h-4" />
        </Button>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-3 justify-end pt-4 border-t border-border">
        <Button
          onClick={() => onConfigured({ sections: templateSections })}
          className="bg-primary text-primary-foreground"
        >
          Analyse Starten
        </Button>
      </div>
    </div>
  )
}
