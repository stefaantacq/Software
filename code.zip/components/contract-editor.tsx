'use client'

import { useState } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Download, Printer, Copy, Check } from 'lucide-react'

interface ContractEditorProps {
  sections: any[]
}

export default function ContractEditor({ sections }: ContractEditorProps) {
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // Mock contract content
  const contractContent = `
VERKOOPSCOMPROMIS ONROEREND GOED

Datum: 15 november 2025

PARTIJEN:
Verkoper(s):
- Naam: Jan de Vries
- Adres: Singel 123, Amsterdam

Koper(s):
- Naam: [In te vullen]
- Adres: [In te vullen]

ONROEREND GOED:
Adres: Singel 123, 1012 AN Amsterdam
Type: Appartement
Oppervlakte: circa 65 m²
Bouwjaar: 1925 (Renovatie 2015)

KOOPPRIJS EN BETALINGSVOORWAARDEN:
Koopprijs: € 425.000,-
Betaald: Bij ondertekening notariële akte
Termijn: 8 weken na ondertekening van dit compromis

ATTESTEN EN DOCUMENTEN:
✓ Asbestverklaring: Aanwezig - Geen asbest
✓ Erfpachtcanon: N.v.t. (eigendomswoning)
⚠ Energielabel (EPC): Nog op te vragen
⚠ Bouwvergunningen: Verificatie nodig

BIJZONDERE BEPALINGEN:
- Dit compromis is onderworpen aan Nederlandse wetgeving
- Beide partijen verplichten zich tot notariele opmaking
- Eventuele erfdienstbaarheden: [Nader onderzoek]

Ondertekend te Amsterdam op [datum]:

Verkoper: ________________
Koper: ________________
Makelaar: ________________
  `

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Contract Preview & Export</h2>
        <p className="text-muted-foreground">
          Controleer je gegenereerde compromis voordat je het exporteert
        </p>
      </div>

      {/* Editor */}
      <Card className="p-6 border border-border bg-card">
        <div className="flex gap-3 mb-6 pb-4 border-b border-border">
          <Button
            size="sm"
            variant="outline"
            className="gap-2"
            onClick={handleCopy}
          >
            {copied ? (
              <>
                <Check className="w-4 h-4" />
                Gekopieerd
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                Kopiëren
              </>
            )}
          </Button>
          <Button size="sm" variant="outline" className="gap-2">
            <Printer className="w-4 h-4" />
            Afdrukken
          </Button>
          <Button size="sm" className="gap-2 bg-primary text-primary-foreground ml-auto">
            <Download className="w-4 h-4" />
            Naar Word
          </Button>
        </div>

        <pre className="bg-muted p-6 rounded-lg text-sm font-mono text-foreground overflow-auto max-h-96 text-pretty">
          {contractContent}
        </pre>
      </Card>

      {/* Tips */}
      <Card className="p-4 border border-border bg-muted/50">
        <h3 className="font-semibold mb-2">Controleer voor export:</h3>
        <ul className="space-y-1 text-sm text-muted-foreground">
          <li>✓ Alle partijgegevens ingevuld</li>
          <li>✓ Adres en eigenschappen accuraat</li>
          <li>⚠ Rode vlaggen opgelost (EPC, bouwvergunning)</li>
          <li>✓ Ondertekeningsdatums ingevuld</li>
        </ul>
      </Card>
    </div>
  )
}
