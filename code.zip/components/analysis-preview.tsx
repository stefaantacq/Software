'use client'

import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Loader2, CheckCircle2, AlertCircle, TrendingUp } from 'lucide-react'

interface PlaceholderSuggestion {
  id: string
  name: string
  suggestion: string
  filled: boolean
  status: 'found' | 'partial' | 'missing'
  confidence: number
  source?: string
}

interface SectionAnalysis {
  section: string
  placeholders: PlaceholderSuggestion[]
  completeness: number
}

interface AnalysisPreviewProps {
  documents: File[]
  templateData: any
  onReady: () => void
}

export default function AnalysisPreview({ documents, templateData, onReady }: AnalysisPreviewProps) {
  const [analyzing, setAnalyzing] = useState(true)
  const [suggestions, setSuggestions] = useState<SectionAnalysis[]>([])
  const [overallCompleteness, setOverallCompleteness] = useState(0)
  const [selectedPlaceholder, setSelectedPlaceholder] = useState<string | null>(null)

  useEffect(() => {
    setTimeout(() => {
      const analysisData: SectionAnalysis[] = [
        {
          section: 'Partijen',
          completeness: 75,
          placeholders: [
            {
              id: 'p1',
              name: 'Verkoper Naam',
              suggestion: 'Jan de Vries',
              filled: true,
              status: 'found',
              confidence: 95,
              source: 'Titel-akten'
            },
            {
              id: 'p2',
              name: 'Verkoper Adres',
              suggestion: 'Automatisch gevonden in notarisdocumenten',
              filled: true,
              status: 'found',
              confidence: 92,
              source: 'Notarisdocumenten'
            },
            {
              id: 'p3',
              name: 'Koper Naam',
              suggestion: 'Nog in te vullen door makelaar',
              filled: false,
              status: 'missing',
              confidence: 0
            },
            {
              id: 'p4',
              name: 'Koper Contactgegevens',
              suggestion: 'Vereist voor volledige compromis',
              filled: false,
              status: 'missing',
              confidence: 0
            }
          ]
        },
        {
          section: 'Onroerend Goed',
          completeness: 85,
          placeholders: [
            {
              id: 'og1',
              name: 'Adres',
              suggestion: 'Singel 123, Amsterdam',
              filled: true,
              status: 'found',
              confidence: 98,
              source: 'Titel-akten'
            },
            {
              id: 'og2',
              name: 'Type Pand',
              suggestion: 'Appartement',
              filled: true,
              status: 'found',
              confidence: 88,
              source: 'Kadastraal onderzoek'
            },
            {
              id: 'og3',
              name: 'Oppervlakte',
              suggestion: '~65 m² (gespecificeerd in inspectierapport)',
              filled: true,
              status: 'partial',
              confidence: 78,
              source: 'Inspectierapport'
            },
            {
              id: 'og4',
              name: 'Bouwjaar',
              suggestion: 'Nader onderzoek nodig',
              filled: false,
              status: 'missing',
              confidence: 0
            }
          ]
        },
        {
          section: 'Koopprijs',
          completeness: 90,
          placeholders: [
            {
              id: 'kp1',
              name: 'Totaalbedrag',
              suggestion: '€ 425.000,-',
              filled: true,
              status: 'found',
              confidence: 100,
              source: 'Schattingsrapport'
            },
            {
              id: 'kp2',
              name: 'Valuta',
              suggestion: 'EUR',
              filled: true,
              status: 'found',
              confidence: 100,
              source: 'Standaard'
            },
            {
              id: 'kp3',
              name: 'Betalingstermijn',
              suggestion: 'Bij ondertekening notariële akte - 8 weken',
              filled: true,
              status: 'found',
              confidence: 85,
              source: 'Standaardvoorwaarden'
            }
          ]
        },
        {
          section: 'Attesten & Documenten',
          completeness: 65,
          placeholders: [
            {
              id: 'ad1',
              name: 'EPC (Energielabel)',
              suggestion: 'ROOD VLAG: Document niet gevonden!',
              filled: false,
              status: 'missing',
              confidence: 0
            },
            {
              id: 'ad2',
              name: 'Asbestverklaring',
              suggestion: 'Gevonden - Geen asbest gedetecteerd',
              filled: true,
              status: 'found',
              confidence: 95,
              source: 'Inspectierapport'
            },
            {
              id: 'ad3',
              name: 'Erfpachtcanon',
              suggestion: 'Niet van toepassing (eigendomswoning)',
              filled: true,
              status: 'found',
              confidence: 100,
              source: 'Kadastraal register'
            },
            {
              id: 'ad4',
              name: 'Bouwvergunning',
              suggestion: 'OPMERKING: Mogelijk renovaties zonder vergunning',
              filled: false,
              status: 'missing',
              confidence: 0
            }
          ]
        }
      ]

      setSuggestions(analysisData)
      const avgCompleteness = Math.round(
        analysisData.reduce((sum, s) => sum + s.completeness, 0) / analysisData.length
      )
      setOverallCompleteness(avgCompleteness)
      setAnalyzing(false)
    }, 2500)
  }, [])

  if (analyzing) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <Loader2 className="w-10 h-10 animate-spin text-primary mb-4" />
        <h3 className="font-semibold mb-1">AI Analyse Bezig...</h3>
        <p className="text-sm text-muted-foreground mb-8">
          Je documenten worden gescand en geanalyseerd
        </p>
        <div className="w-full max-w-xs bg-muted rounded-full h-2">
          <div className="bg-primary h-2 rounded-full w-2/3 animate-pulse"></div>
        </div>
      </div>
    )
  }

  const missingCount = suggestions.flatMap(s => s.placeholders).filter(p => p.status === 'missing').length
  const redFlags = suggestions.flatMap(s => s.placeholders).filter(
    p => p.suggestion?.includes('ROOD VLAG') || p.suggestion?.includes('OPMERKING')
  )

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Analyse Resultaten</h2>
        <p className="text-muted-foreground">
          AI-analyse van je documenten en suggesties per placeholder
        </p>
      </div>

      {/* Overall Stats */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="p-4 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Volledigheid</p>
              <p className="text-2xl font-bold">{overallCompleteness}%</p>
            </div>
            <TrendingUp className="w-8 h-8 text-primary opacity-40" />
          </div>
        </Card>

        <Card className="p-4 border border-border">
          <div>
            <p className="text-sm text-muted-foreground">Ontbrekende Velden</p>
            <p className="text-2xl font-bold text-yellow-600">{missingCount}</p>
          </div>
        </Card>

        <Card className="p-4 border border-border">
          <div>
            <p className="text-sm text-muted-foreground">Rode Vlaggen</p>
            <p className={`text-2xl font-bold ${redFlags.length > 0 ? 'text-red-600' : 'text-green-600'}`}>
              {redFlags.length}
            </p>
          </div>
        </Card>
      </div>

      {/* Alerts */}
      {redFlags.length > 0 && (
        <Card className="p-4 border border-red-200 bg-red-50 dark:bg-red-950/20">
          <h3 className="font-semibold text-red-900 dark:text-red-100 mb-3 flex items-center gap-2">
            <AlertCircle className="w-5 h-5" />
            Waarschuwingen
          </h3>
          <ul className="space-y-2">
            {redFlags.map(flag => (
              <li key={flag.id} className="text-sm text-red-800 dark:text-red-200">
                • {flag.suggestion}
              </li>
            ))}
          </ul>
        </Card>
      )}

      {/* Sections */}
      <div className="space-y-4">
        {suggestions.map((section, i) => (
          <Card key={i} className="p-6 border border-border overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg">{section.section}</h3>
              <div className="flex items-center gap-2">
                <div className="w-20 bg-muted rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full transition-all"
                    style={{ width: `${section.completeness}%` }}
                  ></div>
                </div>
                <span className="text-sm font-medium text-muted-foreground">
                  {section.completeness}%
                </span>
              </div>
            </div>

            <div className="space-y-2">
              {section.placeholders.map((ph) => {
                const isSelected = selectedPlaceholder === ph.id
                const statusColor = {
                  found: 'bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-900',
                  partial: 'bg-yellow-50 dark:bg-yellow-950/20 border-yellow-200 dark:border-yellow-900',
                  missing: 'bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-900'
                }[ph.status]

                return (
                  <button
                    key={ph.id}
                    onClick={() => setSelectedPlaceholder(isSelected ? null : ph.id)}
                    className={`w-full text-left p-3 rounded-lg border transition-all ${statusColor}`}
                  >
                    <div className="flex gap-3 items-start">
                      <div className="flex-shrink-0 pt-0.5">
                        {ph.status === 'found' && (
                          <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400" />
                        )}
                        {ph.status === 'partial' && (
                          <AlertCircle className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
                        )}
                        {ph.status === 'missing' && (
                          <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline gap-2 flex-wrap">
                          <p className="font-medium text-sm">{ph.name}</p>
                          {ph.source && (
                            <span className="text-xs px-2 py-1 bg-background/50 rounded text-muted-foreground">
                              {ph.source}
                            </span>
                          )}
                        </div>
                        <p className={`text-xs mt-1 ${
                          ph.status === 'found' ? 'text-green-700 dark:text-green-300' :
                          ph.status === 'partial' ? 'text-yellow-700 dark:text-yellow-300' :
                          'text-red-700 dark:text-red-300'
                        }`}>
                          {ph.suggestion}
                        </p>
                        {ph.confidence > 0 && (
                          <p className="text-xs text-muted-foreground mt-1">
                            Betrouwbaarheid: {ph.confidence}%
                          </p>
                        )}
                      </div>
                    </div>

                    {isSelected && (
                      <div className="mt-3 pt-3 border-t border-current/20">
                        <textarea
                          className="w-full p-2 text-sm bg-background rounded border border-border"
                          placeholder="Je eigen tekst aanpassen..."
                          defaultValue={ph.suggestion}
                          onClick={(e) => e.stopPropagation()}
                          rows={3}
                        />
                      </div>
                    )}
                  </button>
                )
              })}
            </div>
          </Card>
        ))}
      </div>

      {/* Action Buttons */}
      <div className="flex gap-3 justify-end pt-4 border-t border-border">
        <Button variant="outline">
          Opnieuw Analyseren
        </Button>
        <Button
          onClick={onReady}
          className="bg-primary text-primary-foreground"
        >
          Naar Preview & Export
        </Button>
      </div>
    </div>
  )
}
